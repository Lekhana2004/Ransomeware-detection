import os
import time
from collections import Counter

from monitoring.file_monitor import SnapshotMonitor


def _run(tmp_path, action):
    events = []
    for i in range(5):
        (tmp_path / f"f{i}.txt").write_text("hello world " * 50)
    m = SnapshotMonitor(tmp_path, events.append, poll=0.02)
    m.start(); time.sleep(0.1)
    action(tmp_path)
    time.sleep(0.3); m.stop()
    return events


def test_existing_files_raise_no_events(tmp_path):
    assert _run(tmp_path, lambda d: None) == []


def test_modify_create_delete(tmp_path):
    def act(d):
        (d / "f0.txt").write_text("changed " * 300)
        (d / "new.txt").write_text("x" * 100)
        os.remove(d / "f1.txt")
    ev = _run(tmp_path, act)
    c = Counter(e["kind"] for e in ev)
    assert c["modified"] == 1 and c["created"] == 1 and c["deleted"] == 1


def test_overwrite_then_rename_is_not_hidden(tmp_path):
    """The attacker pattern that broke OS-event monitors: write random bytes, rename at once."""
    def act(d):
        for i in range(5):
            p = d / f"f{i}.txt"
            p.write_bytes(os.urandom(4096))
            p.rename(p.with_suffix(".locked"))
    ev = _run(tmp_path, act)
    mods = [e for e in ev if e["kind"] == "modified"]
    movs = [e for e in ev if e["kind"] == "moved"]
    assert len(mods) == 5 and len(movs) == 5
    assert all(e["entropy"] > 7.5 for e in mods)            # entropy of the FINAL content
    assert all(e["ext_changed"] for e in movs)
