import numpy as np
import pytest

from models.gd_logistic import GDLogisticRegression, sigmoid


def toy(n=400, seed=0):
    rng = np.random.default_rng(seed)
    X = np.vstack([rng.normal(-1, 1, (n // 2, 3)), rng.normal(1, 1, (n // 2, 3))])
    y = np.r_[np.zeros(n // 2), np.ones(n // 2)]
    return X, y


def test_gradient_matches_numerical():
    X, y = toy(60)
    m = GDLogisticRegression(l2=0.01)
    m.w, m.b = np.array([0.3, -0.2, 0.1]), 0.05
    gw, gb = m.gradient(X, y)
    eps = 1e-6
    for j in range(3):
        m.w[j] += eps; up = m.loss(X, y)
        m.w[j] -= 2 * eps; dn = m.loss(X, y)
        m.w[j] += eps
        assert gw[j] == pytest.approx((up - dn) / (2 * eps), abs=1e-6)
    m.b += eps; up = m.loss(X, y); m.b -= 2 * eps; dn = m.loss(X, y); m.b += eps
    assert gb == pytest.approx((up - dn) / (2 * eps), abs=1e-6)


def test_loss_decreases_monotonically_full_batch():
    X, y = toy()
    m = GDLogisticRegression(lr=0.1, n_iter=300).fit(X, y)
    h = np.array(m.loss_history)
    assert np.all(np.diff(h) <= 1e-12)


def test_learns_separable_data():
    X, y = toy()
    m = GDLogisticRegression(lr=0.5, n_iter=800).fit(X, y)
    assert (m.predict(X) == y).mean() > 0.9


def test_ascent_equals_descent():
    X, y = toy()
    d = GDLogisticRegression(lr=0.2, n_iter=200, ascent=False).fit(X, y)
    a = GDLogisticRegression(lr=0.2, n_iter=200, ascent=True).fit(X, y)
    assert np.allclose(d.w, a.w) and d.b == pytest.approx(a.b)


def test_too_large_learning_rate_hurts():
    X, y = toy()
    good = GDLogisticRegression(lr=0.5, n_iter=100, tol=0).fit(X, y)
    bad = GDLogisticRegression(lr=200.0, n_iter=100, tol=0).fit(X, y)
    assert bad.loss_history[-1] > good.loss_history[-1]


def test_sigmoid_bounds():
    assert sigmoid(np.array([-1e4, 0, 1e4])).tolist() == [pytest.approx(0, abs=1e-12), 0.5, pytest.approx(1)]
