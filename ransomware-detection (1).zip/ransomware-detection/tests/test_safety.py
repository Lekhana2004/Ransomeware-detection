import threading
import pytest
from simulation.sandbox import SandboxError, assert_sandbox, run_ransomware_sim


def test_refuses_folder_outside_sandbox(tmp_path):
    (tmp_path / ".SANDBOX_OK").write_text("x")          # marker alone is not enough
    with pytest.raises(SandboxError):
        assert_sandbox(tmp_path)
    with pytest.raises(SandboxError):
        run_ransomware_sim(tmp_path, threading.Event())


def test_refuses_home_and_root():
    for p in ["/", "/home", "/etc"]:
        with pytest.raises(SandboxError):
            assert_sandbox(p)
