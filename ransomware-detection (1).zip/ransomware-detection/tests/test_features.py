import numpy as np
from config import FEATURE_NAMES
from features.feature_extractor import features_from_events, shannon_entropy


def test_entropy_extremes():
    assert shannon_entropy(b"a" * 1000) == 0.0
    rnd = np.random.default_rng(0).integers(0, 256, 65536, dtype=np.uint8).tobytes()
    assert shannon_entropy(rnd) > 7.9


def test_rename_counts_one_file():
    ev = [dict(t=0, kind="modified", path="a.txt", ext_changed=False, entropy=7.9, size=2048),
          dict(t=0.1, kind="moved", path="a.txt", ext_changed=True, entropy=None, size=0)]
    f = dict(zip(FEATURE_NAMES, features_from_events(ev, 1.0, 10)))
    assert f["unique_files"] == 1 and f["ext_change_rate"] == 1 and f["high_entropy_frac"] == 1
    assert f["write_kb"] == 2.0 and f["cpu_percent"] == 10


def test_empty_window():
    assert not features_from_events([], 1.0, 0).any()
