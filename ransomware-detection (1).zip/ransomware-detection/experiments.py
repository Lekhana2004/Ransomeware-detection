"""Live experiments on the sandbox:  python experiments.py
  A) attack speed sweep - detection rate, latency, files lost before the response
  B) benign-only runs    - false alarms during normal use
Results -> data/processed/live_results.json
"""
import json
import multiprocessing as mp
import sys
import threading
import time

import config
from engine import LiveEngine
from run_demo import run
from simulation.sandbox import create_sandbox, run_benign_activity

RATES = [3, 5, 10, 30, 60]
REPEATS = 5
LOAD = "--load" in sys.argv          # emulate a busy laptop: all-core CPU burners


def _burn():
    while True:
        sum(i * i for i in range(10000))


def benign_only(rate, secs=25):
    folder = create_sandbox()
    stop = threading.Event()
    eng = LiveEngine(folder, stop)
    eng.start()
    bstop = threading.Event()
    t = threading.Thread(target=run_benign_activity, args=(folder, bstop, rate), daemon=True)
    t.start(); time.sleep(secs); bstop.set(); t.join(); eng.stop(); eng.alerts.release()
    flags = sum(r["status"] in ("SUSPICIOUS", "ALERT") for r in eng.history)
    return {"edit_rate": rate, "ticks": len(eng.history), "suspicious_ticks": flags,
            "alerts": int(eng.alert_info is not None),
            "max_risk": max(r["risk"] for r in eng.history)}


def main():
    workers = []
    if LOAD:
        workers = [mp.Process(target=_burn, daemon=True) for _ in range(mp.cpu_count())]
        for w in workers:
            w.start()
    out = {"attack": [], "benign": [], "cpu_load": LOAD}
    for rate in RATES:
        for rep in range(REPEATS):
            r = run(files_per_sec=rate, normal_secs=4, verbose=False, attack_timeout=30)
            lat = None if r["detected_after_s"] is None else round(r["detected_after_s"] - r["attack_started_at"], 2)
            out["attack"].append({"files_per_sec": rate, "rep": rep, "detected": r["detected_after_s"] is not None,
                                  "latency_s": lat, "files_encrypted": r["locked_files"]})
            print(out["attack"][-1], flush=True)
    for rate in (2, 8):   # 2 = normal typing, 8 = deliberate stress
        out["benign"].append(benign_only(rate)); print(out["benign"][-1], flush=True)
    for w in workers:
        w.terminate()
    name = "live_results_load.json" if LOAD else "live_results.json"
    (config.DATA_DIR / "processed" / name).write_text(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
