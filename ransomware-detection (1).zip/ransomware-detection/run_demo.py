"""Headless end-to-end demo: normal activity -> simulated attack -> detection -> response.

    python run_demo.py            # prints a timeline
"""
import threading
import time

import config
from engine import LiveEngine
from simulation.sandbox import create_sandbox, run_benign_activity, run_ransomware_sim


def run(files_per_sec=30.0, normal_secs=6, verbose=True, attack_timeout=30):
    folder = create_sandbox()
    stop = threading.Event()                       # shared kill switch
    eng = LiveEngine(folder, stop)
    eng.start()

    benign_stop = threading.Event()
    bt = threading.Thread(target=run_benign_activity, args=(folder, benign_stop, 2.0), daemon=True)
    bt.start()
    time.sleep(normal_secs)                        # Part 1: normal behaviour
    benign_stop.set(); bt.join()

    t_attack = time.time() - eng.t0
    result = {}
    def attack():
        result["encrypted"] = run_ransomware_sim(folder, stop, files_per_sec)
    at = threading.Thread(target=attack, daemon=True)
    at.start()                                     # Part 2: simulated ransomware
    at.join(timeout=attack_timeout)
    time.sleep(1.0)
    eng.stop()
    eng.alerts.release()

    locked = len(list(folder.glob("*.locked")))
    out = {"attack_started_at": round(t_attack, 2),
           "detected_after_s": (eng.alert_info or {}).get("detected_after_s"),
           "files_encrypted_before_stop": result.get("encrypted"),
           "locked_files": locked, "total_files": config.N_DUMMY_FILES,
           "alert": eng.alert_info, "history": eng.history}
    if verbose:
        for r in eng.history:
            print(f"t={r['t']:5.1f}s  files/s={r['files_per_s']:4.0f}  entropy={r['entropy']:.2f}  "
                  f"risk={r['risk']:5.1f}  {r['status']}")
        print(f"\nattack began at t={out['attack_started_at']}s, "
              f"alert at t={out['detected_after_s']}s, "
              f"{locked}/{config.N_DUMMY_FILES} files encrypted before the response stopped it")
        print("actions:", (eng.alert_info or {}).get("actions"))
    return out


if __name__ == "__main__":
    run()
