"""Generate all figures + the worked numeric GD example used in the report.   python analysis.py"""
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import roc_curve

import config
from config import FEATURE_NAMES, FIG_DIR, SEED
from models.gd_logistic import GDLogisticRegression, expand_features, sigmoid
from models.train_model import build_models, predictors
from simulation.data_generator import BENIGN, RANSOM, generate_dataset

plt.rcParams.update({"figure.dpi": 130, "font.size": 9, "axes.grid": True, "grid.alpha": .3})
FIG_DIR.mkdir(parents=True, exist_ok=True)
Xtr, ytr, sctr = generate_dataset(6000, seed=SEED)
Xte, yte, scte = generate_dataset(3000, seed=SEED + 1)
base, iso, rf, gd = build_models(Xtr, ytr)
preds = predictors(base, iso, rf, gd)

# 0. data understanding ------------------------------------------------------
fig, ax = plt.subplots(1, 3, figsize=(11, 3.2))
for i, name in [(6, "mean_entropy"), (5, "unique_files"), (4, "ext_change_rate")]:
    k = [a for a in range(3)][[6, 5, 4].index(i)]
    ax[k].hist(Xtr[ytr == 0, i], bins=40, alpha=.6, label="benign", density=True)
    ax[k].hist(Xtr[ytr == 1, i], bins=40, alpha=.6, label="ransomware-like", density=True)
    ax[k].set_title(name); ax[k].legend()
ax[1].axvline(base.threshold, color="k", ls="--"); ax[1].text(base.threshold + .5, ax[1].get_ylim()[1] * .6, "mu+3sigma", fontsize=8)
fig.tight_layout(); fig.savefig(FIG_DIR / "fig1_feature_distributions.png"); plt.close(fig)

# 1. convergence --------------------------------------------------------------
fig, ax = plt.subplots(1, 2, figsize=(9, 3.2))
ax[0].plot(gd.loss_history); ax[0].set_xscale("log"); ax[0].set_xlabel("iteration"); ax[0].set_ylabel("loss J(w,b)")
ax[0].set_title("Gradient descent: loss vs iteration")
ax[1].semilogy(gd.gradnorm_history); ax[1].set_xlabel("iteration"); ax[1].set_ylabel("||grad J||")
ax[1].set_title("Gradient norm -> 0 at the minimum")
fig.tight_layout(); fig.savefig(FIG_DIR / "fig2_convergence.png"); plt.close(fig)

# 2. learning-rate study --------------------------------------------------------
lrs = [0.001, 0.01, 0.1, 0.5, 5.0, 60.0]
fig, ax = plt.subplots(figsize=(6, 3.6)); lr_final = {}
for lr in lrs:
    m = GDLogisticRegression(lr=lr, n_iter=500, tol=0, expand=True).fit(Xtr, ytr)
    ax.plot(m.loss_history, label=f"eta={lr}"); lr_final[lr] = m.loss_history[-1]
ax.set_yscale("log"); ax.set_xlabel("iteration"); ax.set_ylabel("loss (log)"); ax.legend(ncol=2)
ax.set_title("Effect of the learning rate eta")
fig.tight_layout(); fig.savefig(FIG_DIR / "fig3_learning_rate.png"); plt.close(fig)

# 3. optimiser variants -------------------------------------------------------------
variants = {"full-batch GD (eta=0.5)": dict(lr=0.5),
            "mini-batch SGD, 64 (eta=0.1)": dict(lr=0.1, batch_size=64),
            "full-batch + momentum 0.9 (eta=0.05)": dict(lr=0.05, momentum=0.9)}
fig, ax = plt.subplots(figsize=(6, 3.6)); var_final = {}
for name, kw in variants.items():
    m = GDLogisticRegression(n_iter=800, tol=0, expand=True, **kw).fit(Xtr, ytr)
    ax.plot(m.loss_history, label=name); var_final[name] = m.loss_history[-1]
ax.set_yscale("log"); ax.set_xlabel("update step"); ax.set_ylabel("full-data loss"); ax.legend(fontsize=7)
ax.set_title("Gradient-descent variants")
fig.tight_layout(); fig.savefig(FIG_DIR / "fig4_variants.png"); plt.close(fig)

# 4. ROC ---------------------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(4.8, 4))
for name, (hard, soft) in preds.items():
    fpr, tpr, _ = roc_curve(yte, soft(Xte)); ax.plot(fpr, tpr, label=name)
ax.plot([0, 1], [0, 1], "k:"); ax.set_xlabel("false positive rate"); ax.set_ylabel("true positive rate")
ax.legend(fontsize=7); ax.set_title("ROC curves (independent test set)")
fig.tight_layout(); fig.savefig(FIG_DIR / "fig5_roc.png"); plt.close(fig)

# 5. per-scenario flag rate ------------------------------------------------------------------
scen = BENIGN + RANSOM
M = np.array([[hard(Xte[scte == s]).mean() for s in scen] for _, (hard, _) in preds.items()])
fig, ax = plt.subplots(figsize=(10, 2.8))
im = ax.imshow(M, vmin=0, vmax=1, cmap="RdYlGn_r", aspect="auto"); ax.grid(False)
ax.set_xticks(range(len(scen))); ax.set_xticklabels(scen, rotation=35, ha="right")
ax.set_yticks(range(len(preds))); ax.set_yticklabels(list(preds), fontsize=8)
for i in range(M.shape[0]):
    for j in range(M.shape[1]):
        ax.text(j, i, f"{M[i, j]:.2f}", ha="center", va="center", fontsize=7)
ax.axvline(len(BENIGN) - .5, color="k", lw=2)
ax.set_title("Fraction of windows flagged per scenario (benign left of line: want 0; ransomware right: want 1)")
fig.tight_layout(); fig.savefig(FIG_DIR / "fig6_scenario_heatmap.png"); plt.close(fig)

# 6. interpretable weights (raw-feature GD model) ---------------------------------------------
raw = GDLogisticRegression(lr=0.5, n_iter=3000, expand=False).fit(Xtr, ytr)
order = np.argsort(raw.w)
fig, ax = plt.subplots(figsize=(6, 3.4))
ax.barh([FEATURE_NAMES[i] for i in order], raw.w[order], color=["#c0392b" if w > 0 else "#2980b9" for w in raw.w[order]])
ax.set_xlabel("weight on standardised feature (+ pushes towards 'ransomware')")
ax.set_title("What the gradient-descent model learned (raw features)")
fig.tight_layout(); fig.savefig(FIG_DIR / "fig7_weights.png"); plt.close(fig)

# 7. descent path on the loss surface (2 features) ---------------------------------------------------
cols = [FEATURE_NAMES.index("mean_entropy"), FEATURE_NAMES.index("unique_files")]
X2 = Xtr[:, cols]
m2 = GDLogisticRegression(lr=0.3, n_iter=400, tol=0, l2=1e-3).fit(X2, ytr, keep_w_history=True)
path = np.array(m2.w_history); Xs = (X2 - m2.mu_) / m2.sigma_
g1 = np.linspace(min(-.5, path[:, 0].min() - .3), path[:, 0].max() + .5, 120)
g2 = np.linspace(min(-.5, path[:, 1].min() - .3), path[:, 1].max() + .5, 120)
Z = np.zeros((len(g2), len(g1)))
for i, b2 in enumerate(g2):
    for j, b1 in enumerate(g1):
        p = np.clip(sigmoid(Xs @ np.array([b1, b2]) + m2.b), 1e-12, 1 - 1e-12)
        Z[i, j] = -np.mean(ytr * np.log(p) + (1 - ytr) * np.log(1 - p)) + .5 * m2.l2 * (b1 ** 2 + b2 ** 2)
fig, ax = plt.subplots(figsize=(5.2, 4))
cs = ax.contour(g1, g2, Z, levels=25, cmap="viridis"); ax.clabel(cs, fontsize=6)
ax.plot(path[:, 0], path[:, 1], "r.-", ms=3, lw=1, label="GD path (every step)")
ax.plot(0, 0, "ko", label="start w=(0,0)"); ax.plot(*path[-1], "r*", ms=12, label="end")
ax.set_xlabel("w1 (mean_entropy)"); ax.set_ylabel("w2 (unique_files)"); ax.legend(fontsize=7)
ax.set_title("Gradient descent walking down the loss surface")
fig.tight_layout(); fig.savefig(FIG_DIR / "fig8_gd_path.png"); plt.close(fig)

# 8. worked numeric example (for the appendix / viva board work) -----------------------------------------
Xw = np.array([[1.0, 2.0], [-1.0, -1.0], [2.0, 1.0]]); yw = np.array([1.0, 0.0, 1.0])
w, b, eta = np.zeros(2), 0.0, 0.5
steps = []
for k in range(2):
    p = sigmoid(Xw @ w + b); err = p - yw
    gw = Xw.T @ err / 3; gb = err.mean(); L = -np.mean(yw * np.log(p) + (1 - yw) * np.log(1 - p))
    steps.append(dict(step=k + 1, w=w.tolist(), b=b, p=p.round(4).tolist(), err=err.round(4).tolist(),
                      gw=gw.round(4).tolist(), gb=round(float(gb), 4), loss=round(float(L), 4)))
    w, b = w - eta * gw, b - eta * gb
    steps[-1].update(w_new=w.round(4).tolist(), b_new=round(float(b), 4))
L2 = -np.mean(yw * np.log(sigmoid(Xw @ w + b)) + (1 - yw) * np.log(1 - sigmoid(Xw @ w + b)))
(config.DATA_DIR / "processed" / "worked_example.json").write_text(json.dumps({"steps": steps, "loss_after": round(float(L2), 4)}, indent=2))
(config.DATA_DIR / "processed" / "analysis_extras.json").write_text(json.dumps({
    "lr_final_loss": {str(k): v for k, v in lr_final.items()}, "variant_final_loss": var_final,
    "raw_weights": dict(zip(FEATURE_NAMES, raw.w.round(3).tolist())),
    "gd_iterations": len(gd.loss_history), "gd_final_loss": gd.loss_history[-1],
    "gd_loss_at": {str(i): gd.loss_history[min(i, len(gd.loss_history)) - 1] for i in (1, 10, 100, 1000, 3000)},
    "n_features_expanded": int(expand_features(Xtr[:1]).shape[1])}, indent=2))
print(json.dumps(steps, indent=1)); print("figures written to", FIG_DIR)

# 9. live timeline from a real sandbox run ---------------------------------------------------------------
from run_demo import run
r = run(files_per_sec=30, normal_secs=5, verbose=False)
H = r["history"]; t = [h["t"] for h in H]
fig, ax = plt.subplots(2, 1, figsize=(8, 4.6), sharex=True)
ax[0].plot(t, [h["files_per_s"] for h in H], "b.-"); ax[0].set_ylabel("files changed / s")
ax[1].plot(t, [h["risk"] for h in H], "r.-", label="GD risk score"); ax[1].axhline(100 * config.ALERT_PROB, color="gray", ls="--", label="alert level")
ax[1].set_ylabel("risk (0-100)"); ax[1].set_xlabel("time (s)")
for a in ax:
    a.axvline(r["attack_started_at"], color="k", ls=":"); 
    if r["detected_after_s"]: a.axvline(r["detected_after_s"], color="g", lw=2)
ax[1].legend(loc="upper left", fontsize=7)
ax[0].set_title(f"Live run: attack (dotted) -> alert (green) after {r['detected_after_s'] - r['attack_started_at']:.2f}s, "
                f"{r['locked_files']}/50 files affected")
fig.tight_layout(); fig.savefig(FIG_DIR / "fig9_live_timeline.png"); plt.close(fig)
json.dump({k: v for k, v in r.items() if k != "history"}, open(config.DATA_DIR / "processed" / "demo_run.json", "w"), indent=2, default=str)
print("live run:", r["detected_after_s"], r["attack_started_at"], r["locked_files"])
