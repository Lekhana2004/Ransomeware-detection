"""Streamlit dashboard:   streamlit run app.py

Demo flow:  1 Start monitoring -> 2 Start normal activity -> 3 Launch simulated attack
            -> watch detection + response -> 4 Reset.
Everything happens inside ./sandbox/test_folder with harmless dummy files.
"""
import json
import threading

import pandas as pd
import streamlit as st

import config
from engine import LiveEngine
from simulation.sandbox import create_sandbox, run_benign_activity, run_ransomware_sim

st.set_page_config(page_title="Ransomware Behaviour Detector", page_icon="🛡️", layout="wide")
ss = st.session_state
for k, v in dict(engine=None, benign_stop=None, attack_thread=None).items():
    ss.setdefault(k, v)


def stop_all():
    if ss.benign_stop:
        ss.benign_stop.set()
    if ss.engine:
        ss.engine.stop_event.set()
        ss.engine.stop()
        ss.engine.alerts.release()
    ss.engine, ss.benign_stop, ss.attack_thread = None, None, None


st.title("🛡️ Ransomware Behaviour Detection - gradient-descent model")
st.caption("Safe simulation: dummy files only, inside the sandbox folder. No real malware, no real encryption.")

with st.sidebar:
    st.header("Controls")
    speed = st.slider("Simulated attack speed (files/s)", 3, 60, 30)
    if st.button("1 · Start monitoring", use_container_width=True):
        stop_all()
        folder = create_sandbox()
        ss.engine = LiveEngine(folder, threading.Event())
        ss.engine.start()
    if st.button("2 · Start normal activity", use_container_width=True, disabled=ss.engine is None):
        ss.benign_stop = threading.Event()
        threading.Thread(target=run_benign_activity, daemon=True,
                         args=(config.SANDBOX_DIR, ss.benign_stop, 2.0)).start()
    if st.button("3 · Launch simulated ransomware", type="primary", use_container_width=True,
                 disabled=ss.engine is None):
        if ss.benign_stop:
            ss.benign_stop.set()
        ss.attack_thread = threading.Thread(
            target=run_ransomware_sim, daemon=True,
            args=(config.SANDBOX_DIR, ss.engine.stop_event, float(speed)))
        ss.attack_thread.start()
    if st.button("4 · Reset (needed after every alert)", use_container_width=True):
        stop_all()
        create_sandbox()
    st.divider()
    st.markdown(f"**Alert rule:** GD probability ≥ {config.ALERT_PROB} for {config.CONSECUTIVE} "
                f"consecutive {config.TICK_SEC}s ticks")


@st.fragment(run_every=0.5)
def live_panel():
    eng = ss.engine
    if eng is None:
        st.info("Press **1 · Start monitoring** in the sidebar.")
        return
    hist = eng.history
    last = hist[-1] if hist else dict(status="STARTING", risk=0.0, files_per_s=0.0, entropy=0.0,
                                      rf_prob=0.0, iso_flag=False, baseline_flag=False)
    locked = len(list(config.SANDBOX_DIR.glob("*.locked")))
    banner = {"ALERT": ("🚨 THREAT DETECTED", st.error), "BLOCKED": ("🛑 ACTIVITY BLOCKED - folder isolated", st.error),
              "SUSPICIOUS": ("⚠️ Suspicious activity", st.warning)}.get(last["status"], ("🟢 NORMAL", st.success))
    banner[1](banner[0])
    c = st.columns(5)
    c[0].metric("Files changed / s", f"{last['files_per_s']:.0f}")
    c[1].metric("Mean write entropy (bits/B)", f"{last['entropy']:.2f}")
    c[2].metric("Risk score (GD model)", f"{last['risk']:.0f} / 100")
    c[3].metric("Files 'locked'", f"{locked} / {config.N_DUMMY_FILES}")
    c[4].metric("RF prob.", f"{100 * last['rf_prob']:.0f}%")
    if hist:
        df = pd.DataFrame(hist[-80:]).set_index("t")
        a, b = st.columns(2)
        a.caption("Risk score (0-100)"); a.line_chart(df[["risk"]], height=220)
        b.caption("Files changed per second"); b.line_chart(df[["files_per_s"]], height=220)
    if eng.alert_info:
        i = eng.alert_info
        st.subheader("Response")
        for act in i["actions"]:
            st.write("✓", act)
        st.caption(f"Detected {i['detected_after_s']}s after monitoring started · risk {i['risk_score']} · "
                   f"top writer: {i['top_writers'][0]['name'] if i['top_writers'] else 'n/a'}")
    log = config.LOG_DIR / "alerts.jsonl"
    if log.exists():
        with st.expander("Alert log (logs/alerts.jsonl)"):
            rows = [json.loads(x) for x in log.read_text().splitlines()[-10:]]
            st.dataframe(pd.DataFrame(rows)[["time", "risk_score", "files_per_s", "mean_entropy", "actions"]])


live_panel()
