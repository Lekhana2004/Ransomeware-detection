"""Alerting and safe response: log -> kill switch -> quarantine (restrict folder)."""
from __future__ import annotations

import json
import os
import stat
import threading
import time
from pathlib import Path

from config import LOG_DIR
from simulation.sandbox import assert_sandbox


class AlertManager:
    def __init__(self, folder, stop_event: threading.Event | None = None,
                 log_path: Path = LOG_DIR / "alerts.jsonl"):
        self.folder = assert_sandbox(folder)          # response only ever acts inside the sandbox
        self.stop_event = stop_event or threading.Event()
        self.log_path = Path(log_path)
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self.quarantined = False

    def quarantine(self):
        """Protection: make the monitored folder and its files read-only (race-safe)."""
        for p in list(self.folder.iterdir()):
            try:
                os.chmod(p, 0o444)
            except FileNotFoundError:          # renamed by the attacker while we iterate
                continue
        os.chmod(self.folder, 0o555)           # no new files, no renames from now on
        self.quarantined = True

    def release(self):
        """Undo quarantine: the sandbox is ours, so restore the standard modes."""
        try:
            os.chmod(self.folder, 0o755)
            for p in self.folder.iterdir():
                try:
                    os.chmod(p, 0o644)
                except OSError:
                    pass
        except OSError:
            pass
        self.quarantined = False

    def trigger(self, info: dict) -> list[str]:
        actions = []
        self.stop_event.set()                          # Response: stop the (simulated) attacker
        actions.append("activity stopped (kill switch)")
        try:
            self.quarantine()                          # Protection: restrict the folder
            actions.append("folder isolated (read-only)")
        except OSError as e:
            actions.append(f"quarantine failed: {e}")
        record = {"time": time.strftime("%Y-%m-%d %H:%M:%S"), "actions": actions, **info}
        with open(self.log_path, "a") as f:            # Alert: persistent log
            f.write(json.dumps(record) + "\n")
        actions.append("alert logged")
        return actions
