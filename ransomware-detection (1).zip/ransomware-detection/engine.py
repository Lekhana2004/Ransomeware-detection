"""Real-time detection engine: watchdog events -> window features -> detectors -> response."""
from __future__ import annotations

import threading
import time

from config import (ALERT_PROB, CONSECUTIVE, SANDBOX_DIR, TICK_SEC, WINDOW_SEC)
from features.feature_extractor import WindowFeatureExtractor
from models.predict import DetectorBank
from monitoring.file_monitor import FileMonitor
from monitoring.process_monitor import system_context, top_writers
from response.alert_manager import AlertManager


class LiveEngine:
    def __init__(self, folder=SANDBOX_DIR, stop_event: threading.Event | None = None):
        self.folder = folder
        self.stop_event = stop_event or threading.Event()   # shared with the simulator = kill switch
        self.extractor = WindowFeatureExtractor(WINDOW_SEC)
        self.bank = DetectorBank()
        self.alerts = AlertManager(folder, self.stop_event)
        self._responding = False
        self.monitor = FileMonitor(folder, self._on_event)
        self.history: list[dict] = []
        self.alert_info: dict | None = None
        self._run = threading.Event()
        self._thread: threading.Thread | None = None
        self._streak = 0
        self.t0 = None

    def _on_event(self, ev):
        if not self._responding:            # ignore events caused by our own quarantine chmod
            self.extractor.add(ev)

    def start(self):
        self.t0 = time.time()
        system_context()                    # prime psutil's cpu counter
        self.monitor.start()
        self._run.set()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._run.clear()
        if self._thread:
            self._thread.join(timeout=2)
        self.monitor.stop()

    def _loop(self):
        while self._run.is_set():
            time.sleep(TICK_SEC)
            now = time.time()
            ctx = system_context()
            x = self.extractor.compute(now, ctx["cpu"])
            s = self.bank.score(x)
            self._streak = self._streak + 1 if s["gd_prob"] >= ALERT_PROB else 0
            row = {"t": round(now - self.t0, 2), "risk": round(100 * s["gd_prob"], 1),
                   "files_per_s": float(x[5]), "entropy": float(x[6]),
                   "status": "NORMAL", **s}
            if self._streak >= CONSECUTIVE and self.alert_info is None:
                row["status"] = "ALERT"
                self._responding = True
                info = {"risk_score": row["risk"], "files_per_s": row["files_per_s"],
                        "mean_entropy": row["entropy"], "top_writers": top_writers(),
                        "detected_after_s": row["t"]}
                info["actions"] = self.alerts.trigger(info)
                self.alert_info = info
            elif self.alert_info is not None:
                row["status"] = "BLOCKED"
            elif s["gd_prob"] >= ALERT_PROB:
                row["status"] = "SUSPICIOUS"
            self.history.append(row)
