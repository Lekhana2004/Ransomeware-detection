"""Central settings for the ransomware-behaviour detector.

Everything the detector, simulator and dashboard must agree on lives here, so
that training-time and run-time feature definitions can never drift apart.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parent

# ---- Safe sandbox ---------------------------------------------------------
# The simulator and the monitor ONLY ever touch this folder.
SANDBOX_ROOT = ROOT / "sandbox"
SANDBOX_DIR = SANDBOX_ROOT / "test_folder"
SANDBOX_MARKER = ".SANDBOX_OK"          # simulator refuses to run without it
N_DUMMY_FILES = 50

# ---- Monitoring backend -----------------------------------------------------
# "snapshot": deterministic folder snapshots (os.scandir + stat) every POLL_SEC; identical on
#             Linux / macOS / Windows.  "watchdog": OS event API (inotify / FSEvents / ReadDirectoryChangesW)
#             - lower overhead but delivery timing and coalescing differ per OS.
MONITOR_BACKEND = "snapshot"
POLL_SEC = 0.05

# ---- Windowing ------------------------------------------------------------
WINDOW_SEC = 1.0      # length of the sliding window that features are built from
TICK_SEC = 0.25       # how often the live engine scores the window

# ---- Features (order matters: it is the column order of the model input) ---
FEATURE_NAMES = [
    "mod_rate",          # modified events / s
    "rename_rate",       # renames (moves) / s
    "create_rate",       # created files / s
    "delete_rate",       # deleted files / s
    "ext_change_rate",   # renames that CHANGE the file extension / s
    "unique_files",      # distinct files touched in the window ("files changed/sec")
    "mean_entropy",      # mean Shannon entropy (bits/byte) of written content
    "high_entropy_frac", # fraction of written files with entropy > 7.0
    "write_kb",          # kilobytes written in the window
    "cpu_percent",       # system CPU % (psutil)
]
BASELINE_FEATURE = "unique_files"   # feature used by the mean + 3*sigma baseline
HIGH_ENTROPY = 7.0

# ---- Decision logic -------------------------------------------------------
ALERT_PROB = 0.70     # GD model probability above which a window is "suspicious"
CONSECUTIVE = 2       # ... for this many consecutive ticks => ALERT + RESPONSE
SIGMA_K = 3.0         # baseline threshold = mu + SIGMA_K * sigma

# ---- Paths ----------------------------------------------------------------
MODELS_DIR = ROOT / "models"
LOG_DIR = ROOT / "logs"
FIG_DIR = ROOT / "reports" / "figures"
REPORT_DIR = ROOT / "reports"
DATA_DIR = ROOT / "data"
SEED = 42
