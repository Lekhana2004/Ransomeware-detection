"""One-command health check for YOUR machine:   python selftest.py

Runs: sandbox safety guard, monitor event capture, 3 live attacks at different speeds and a
benign-only run. Prints PASS/FAIL per check and exits non-zero if anything fails.
"""
import sys
import threading
import time
from collections import Counter

import config
from monitoring.file_monitor import FileMonitor
from run_demo import run
from simulation.sandbox import create_sandbox, run_benign_activity, run_ransomware_sim

results = []


def check(name, ok, detail=""):
    results.append(ok)
    print(f"[{'PASS' if ok else 'FAIL'}] {name} {detail}")


# 1. monitor sees every write + rename of a fast attack ------------------------------------------
folder = create_sandbox(); ev = []
m = FileMonitor(folder, ev.append); m.start(); time.sleep(0.3)
run_ransomware_sim(folder, threading.Event(), 30.0); time.sleep(0.5); m.stop()
c = Counter(e["kind"] for e in ev)
check("monitor captures all 50 writes and 50 renames", c["modified"] == 50 and c["moved"] == 50, str(dict(c)))
ent = [e["entropy"] for e in ev if e["kind"] == "modified" and e["entropy"] is not None]
check("entropy of encrypted writes > 7.5 bits/byte", len(ent) == 50 and min(ent) > 7.5)

# 2. live end-to-end attacks -----------------------------------------------------------------------
for rate in (5, 30, 60):
    r = run(files_per_sec=rate, normal_secs=3, verbose=False)
    lat = None if r["detected_after_s"] is None else r["detected_after_s"] - r["attack_started_at"]
    ok = lat is not None and lat < 2.0 and r["locked_files"] < config.N_DUMMY_FILES
    check(f"attack at {rate:>2} files/s detected + stopped", ok,
          f"(delay {lat:.2f}s, {r['locked_files']}/50 files affected)" if lat is not None else "(NOT detected)")
    acts = (r["alert"] or {}).get("actions", [])
    check(f"response actions complete at {rate} files/s",
          "activity stopped (kill switch)" in acts and "folder isolated (read-only)" in acts and "alert logged" in acts, str(acts))

# 3. no false alarm during normal editing -----------------------------------------------------------
folder = create_sandbox()
from engine import LiveEngine
stop = threading.Event(); eng = LiveEngine(folder, stop); eng.start()
bs = threading.Event(); t = threading.Thread(target=run_benign_activity, args=(folder, bs, 2.0), daemon=True); t.start()
time.sleep(12); bs.set(); t.join(); eng.stop(); eng.alerts.release()
check("no alert during 12 s of normal editing", eng.alert_info is None,
      f"(max risk {max(r['risk'] for r in eng.history):.0f})")

print(f"\n{sum(results)}/{len(results)} checks passed")
sys.exit(0 if all(results) else 1)
