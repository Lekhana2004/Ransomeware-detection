"""Synthetic training data: event streams for benign and ransomware-like behaviour.

Each scenario produces the *events* of one 1-second window; those events are
passed through the SAME feature extractor used live.  Scenarios deliberately
overlap (e.g. benign build bursts are as fast as slow ransomware; benign
archives are as high-entropy as ciphertext) so that a single-feature threshold
cannot separate the classes.  All numbers are design assumptions, documented in
the report - they are not measurements of real malware.
"""
from __future__ import annotations

import numpy as np

from config import FEATURE_NAMES, SEED, WINDOW_SEC
from features.feature_extractor import features_from_events

BENIGN = ["idle", "editing", "build_burst", "archive_media", "bulk_convert", "encrypted_backup", "heavy_edit"]
RANSOM = ["fast_encrypt", "medium_encrypt", "stealth_slow", "in_place_no_rename", "intermittent", "ramp_up"]


def _events(rng, n_mod, n_ren, n_new, n_del, ext_frac, ent_mu, ent_sd, size_kb, pool=50,
            unique_files=True):
    ev = []
    t = lambda: float(rng.uniform(0, WINDOW_SEC))
    ids = rng.permutation(pool)
    k = 0
    for i in range(n_mod):
        fid = ids[k % pool] if unique_files else rng.integers(pool)
        k += 1
        ev.append(dict(t=t(), kind="modified", path=f"f{fid}.txt", ext_changed=False,
                       entropy=float(np.clip(rng.normal(ent_mu, ent_sd), 0, 8)),
                       size=int(max(0.2, rng.normal(size_kb, size_kb * .3)) * 1024)))
        if i < n_ren:                                  # rename the file just written
            ev.append(dict(t=t(), kind="moved", path=f"f{fid}.txt",
                           ext_changed=bool(rng.random() < ext_frac), entropy=None, size=0))
    for _ in range(max(0, n_ren - n_mod)):             # renames without a write
        ev.append(dict(t=t(), kind="moved", path=f"f{ids[k % pool]}.txt",
                       ext_changed=bool(rng.random() < ext_frac), entropy=None, size=0)); k += 1
    for _ in range(n_new):
        ev.append(dict(t=t(), kind="created", path=f"n{rng.integers(10**6)}.txt", ext_changed=False,
                       entropy=float(np.clip(rng.normal(ent_mu, ent_sd), 0, 8)),
                       size=int(max(0.2, rng.normal(size_kb, size_kb * .3)) * 1024)))
    for _ in range(n_del):
        ev.append(dict(t=t(), kind="deleted", path=f"d{rng.integers(10**6)}.txt", ext_changed=False,
                       entropy=None, size=0))
    return ev


def _cpu(rng, mu, sd):
    """Host load is mostly UNRELATED to the class: a random background load (0-100 %) plus a small
    scenario-dependent bump. A busy laptop must not hide an attack, nor an idle one create alarms."""
    return float(np.clip(rng.uniform(0, 100) + 0.25 * (mu - 20) + rng.normal(0, 3), 0, 100))


def make_window(rng, scenario: str):
    P = rng.poisson
    if scenario == "idle":
        ev = _events(rng, P(0.3), 0, P(0.05), P(0.03), 0, 4.3, .5, 4)
        cpu = _cpu(rng, 3, 2)
    elif scenario == "editing":
        n = max(1, P(2.5))
        ev = _events(rng, n, P(.1), P(.15), P(.1), .05, 4.3, .6, 5, unique_files=False)
        cpu = _cpu(rng, 8, 5)
    elif scenario == "heavy_edit":                        # e.g. autosave / log writing / IDE: many edits, no renames
        ev = _events(rng, max(4, P(8)), 0, P(0.2), 0, 0, 4.3, .6, 3, pool=15, unique_files=False)
        cpu = _cpu(rng, 8, 5)
    elif scenario == "build_burst":                       # compile / git checkout / backup
        n = P(14)
        ev = _events(rng, n, P(2), P(8), P(3), .1, 5.0, 1.0, 12)
        cpu = _cpu(rng, 35, 15)
    elif scenario == "archive_media":                     # zip / jpeg / mp4 -> high entropy, benign
        ev = _events(rng, P(3), 0, P(2), 0, 0.0, 7.6, .2, 40)
        cpu = _cpu(rng, 38, 12)
    elif scenario == "bulk_convert":                      # photo/doc converter: renames + new extension
        n = max(2, P(6))
        ev = _events(rng, n, n, 0, 0, .9, 7.55, .3, 20)
        cpu = _cpu(rng, 30, 12)
    elif scenario == "encrypted_backup":                  # legit encryption tool / encrypted sync
        n = max(2, P(7))
        ev = _events(rng, n, int(n * .7), P(2), 0, .6, 7.85, .12, 20)
        cpu = _cpu(rng, 28, 14)
    elif scenario == "ramp_up":                           # first moments of an attack: 1-2 files only
        n = max(1, P(1.5))
        ev = _events(rng, n, n, 0, 0, .95, 7.85, .12, 16)
        cpu = _cpu(rng, 8, 6)
    elif scenario == "fast_encrypt":
        n = max(8, P(25))
        ev = _events(rng, n, int(n * rng.uniform(.8, 1.0)), 0, 0, .95, 7.88, .10, 18)
        cpu = _cpu(rng, 30, 18)
    elif scenario == "medium_encrypt":
        n = max(4, P(10))
        ev = _events(rng, n, int(n * rng.uniform(.8, 1.0)), 0, 0, .95, 7.88, .10, 18)
        cpu = _cpu(rng, 25, 15)
    elif scenario == "stealth_slow":                      # throttled to hide among normal edits
        n = max(2, P(3.5))
        ev = _events(rng, n, n, 0, 0, .95, 7.85, .12, 16)
        cpu = _cpu(rng, 12, 8)
    elif scenario == "in_place_no_rename":                # overwrites in place, keeps names
        n = max(5, P(18))
        ev = _events(rng, n, 0, 0, 0, 0, 7.88, .10, 18)
        cpu = _cpu(rng, 28, 15)
    elif scenario == "intermittent":                      # encrypts only part of each file
        n = max(5, P(12))
        ev = _events(rng, n, n, 0, 0, .9, 6.3, .6, 16)
        cpu = _cpu(rng, 22, 12)
    else:
        raise ValueError(scenario)
    if scenario in RANSOM and rng.random() < 0.5:         # user keeps working during the attack
        ev += [dict(e, path="bg_" + e["path"]) for e in
               _events(rng, P(1.5), 0, 0, 0, 0, 4.3, .6, 5, unique_files=False)]
    return features_from_events(ev, WINDOW_SEC, cpu)


def generate_dataset(n: int = 6000, ransom_frac: float = 0.35, seed: int = SEED):
    """Return X (n x d), y (0 benign / 1 ransomware), scenario label per row."""
    rng = np.random.default_rng(seed)
    X, y, sc = [], [], []
    for _ in range(n):
        if rng.random() < ransom_frac:
            s = RANSOM[rng.choice(len(RANSOM), p=[.26, .17, .17, .13, .13, .14])]
            y.append(1)
        else:
            s = BENIGN[rng.choice(len(BENIGN), p=[.22, .28, .13, .09, .09, .06, .13])]
            y.append(0)
        X.append(make_window(rng, s)); sc.append(s)
    return np.vstack(X), np.array(y), np.array(sc)


def save_csv(path, X, y, sc):
    import pandas as pd
    df = pd.DataFrame(X, columns=FEATURE_NAMES)
    df["label"], df["scenario"] = y, sc
    df.to_csv(path, index=False)
    return df
