"""Safe test environment: dummy files, benign activity and a ransomware SIMULATOR.

SAFETY DESIGN
  * No real malware and no real encryption. The "attack" overwrites dummy files
    (that this module itself generated) with random bytes - which has the same
    high-entropy signature as ciphertext - and renames them *.locked.
  * Every function calls `assert_sandbox()`: the target must be inside
    config.SANDBOX_ROOT AND contain the marker file, otherwise it refuses to run.
  * A threading.Event ("kill switch") stops the simulation immediately.
"""
from __future__ import annotations

import os
import random
import threading
import time
from pathlib import Path

from config import N_DUMMY_FILES, SANDBOX_DIR, SANDBOX_MARKER, SANDBOX_ROOT

WORDS = ("report budget meeting project invoice student network security data user "
         "login server backup update policy review summary schedule client office "
         "travel note idea draft final minutes agenda budget quarter result").split()


class SandboxError(RuntimeError):
    pass


def assert_sandbox(folder) -> Path:
    folder = Path(folder).resolve()
    root = SANDBOX_ROOT.resolve()
    if root not in folder.parents and folder != root:
        raise SandboxError(f"{folder} is outside the sandbox root {root}")
    if not (folder / SANDBOX_MARKER).exists():
        raise SandboxError(f"{folder} has no {SANDBOX_MARKER} marker - refusing to run")
    return folder


def _text(rng, kb):
    out, size = [], 0
    while size < kb * 1024:
        w = rng.choice(WORDS)
        out.append(w); size += len(w) + 1
    return " ".join(out)


def create_sandbox(folder=SANDBOX_DIR, n_files=N_DUMMY_FILES, seed=1) -> Path:
    """(Re)create the test folder with n harmless text files."""
    folder = Path(folder)
    if folder.exists():
        os.chmod(folder, 0o755)                # may still be read-only from an earlier quarantine
        for p in folder.iterdir():
            if p.is_file():
                os.chmod(p, 0o644)
                p.unlink()
    folder.mkdir(parents=True, exist_ok=True)
    os.chmod(folder, 0o755)
    (folder / SANDBOX_MARKER).write_text("sandbox for ransomware-behaviour simulation\n")
    rng = random.Random(seed)
    for i in range(n_files):
        (folder / f"document{i:02d}.txt").write_text(_text(rng, rng.choice([4, 6, 8])))
    return folder


def run_benign_activity(folder, stop: threading.Event, rate=2.0, duration=None, seed=2):
    """Normal user behaviour: occasionally edit a text file (~`rate` per second)."""
    folder = assert_sandbox(folder)
    rng = random.Random(seed)
    t0 = time.time()
    while not stop.is_set() and (duration is None or time.time() - t0 < duration):
        files = [p for p in folder.glob("*.txt")]
        if files:
            p = rng.choice(files)
            try:
                with open(p, "a") as f:
                    f.write(" " + _text(rng, 1))
            except OSError:
                return
        stop.wait(rng.expovariate(rate))


def run_ransomware_sim(folder, stop: threading.Event, files_per_sec=30.0, progress=None):
    """Simulated ransomware: overwrite each dummy file with random bytes, rename to .locked.

    Returns the number of dummy files 'encrypted' before it finished or was stopped.
    """
    folder = assert_sandbox(folder)
    targets = sorted(folder.glob("*.txt"))
    done = 0
    for p in targets:
        if stop.is_set():
            break
        try:
            size = p.stat().st_size
            with open(p, "wb") as f:
                f.write(os.urandom(size))             # high-entropy "ciphertext"
            p.rename(p.with_suffix(".locked"))        # extension change
        except OSError:                                # e.g. folder quarantined -> blocked
            break
        done += 1
        if progress:
            progress(done, len(targets))
        stop.wait(1.0 / files_per_sec)
    return done
