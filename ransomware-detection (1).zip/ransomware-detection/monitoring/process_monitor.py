"""psutil helpers: system resource context and (best-effort) top disk-writing processes."""
from __future__ import annotations

import psutil


def system_context() -> dict:
    """CPU/memory snapshot. cpu_percent(None) = usage since the previous call (non-blocking)."""
    return {"cpu": psutil.cpu_percent(interval=None), "mem": psutil.virtual_memory().percent}


def top_writers(n: int = 3):
    """Processes with the most cumulative bytes written - used only to enrich an alert."""
    rows = []
    for p in psutil.process_iter(["pid", "name"]):
        try:
            io = p.io_counters()
            rows.append((io.write_bytes, p.info["pid"], p.info["name"]))
        except (psutil.Error, AttributeError, OSError):
            continue
    rows.sort(reverse=True)
    return [{"pid": pid, "name": name, "write_mb": round(b / 1e6, 1)} for b, pid, name in rows[:n]]
