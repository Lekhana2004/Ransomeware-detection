"""Watchdog-based file-system monitor. Emits the dict events the feature extractor expects."""
from __future__ import annotations

import os
import threading
import time
from pathlib import Path
from typing import Callable

from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer

import config
from features.feature_extractor import shannon_entropy

DEDUP_SEC = 0.05          # inotify often fires 2 'modified' events per write


class _Handler(FileSystemEventHandler):
    def __init__(self, sink: Callable[[dict], None]):
        self.sink = sink
        self._last_mod: dict[str, float] = {}
        self._pending: dict[str, dict] = {}      # stem -> modified event whose content was unreadable

    def _read(self, path):
        """(entropy, size) of the file, or (None, None) if it no longer exists at `path`."""
        try:
            with open(path, "rb") as f:
                data = f.read(65536)
            return shannon_entropy(data), Path(path).stat().st_size
        except OSError:
            return None, None

    def _emit(self, kind, path, ext_changed=False, entropy=None, size=0):
        ev = dict(t=time.time(), kind=kind, path=str(path),
                  ext_changed=ext_changed, entropy=entropy, size=size)
        self.sink(ev)
        return ev

    def on_created(self, e):
        if e.is_directory or Path(e.src_path).name.startswith("."):
            return
        ent, size = self._read(e.src_path)
        self._emit("created", e.src_path, entropy=ent, size=size or 0)

    def on_modified(self, e):
        if e.is_directory or Path(e.src_path).name.startswith("."):
            return
        now = time.time()
        if now - self._last_mod.get(e.src_path, 0) < DEDUP_SEC:
            return
        ent, size = self._read(e.src_path)
        if size == 0:                       # truncate-before-write: wait for the real write
            return
        self._last_mod[e.src_path] = now
        if size is None:
            # File already renamed/deleted before we could read it (a fast attacker wins the
            # race). Still count the write; entropy/size are back-filled when the rename arrives.
            ev = self._emit("modified", e.src_path, entropy=None, size=0)
            self._pending[Path(e.src_path).stem] = ev
        else:
            self._emit("modified", e.src_path, entropy=ent, size=size)

    def on_moved(self, e):
        if e.is_directory:
            return
        changed = Path(e.src_path).suffix != Path(e.dest_path).suffix
        pend = self._pending.pop(Path(e.src_path).stem, None)
        if pend is not None:                # back-fill the content measurements of the missed read
            ent, size = self._read(e.dest_path)
            pend["entropy"], pend["size"] = ent, size or 0
        self._emit("moved", e.src_path, ext_changed=changed)

    def on_deleted(self, e):
        if not e.is_directory:
            self._emit("deleted", e.src_path)


class WatchdogMonitor:
    """OS-event backend (watchdog). Kept for the project brief; see SnapshotMonitor for the default."""

    def __init__(self, folder, sink: Callable[[dict], None]):
        self.folder, self.sink = str(folder), sink
        self.observer = Observer()

    def start(self):
        self.observer.schedule(_Handler(self.sink), self.folder, recursive=False)
        self.observer.start()

    def stop(self):
        self.observer.stop()
        self.observer.join(timeout=2)


def _read_file(path):
    """(entropy, size) of the current content of `path`, or (None, None) if unreadable."""
    try:
        with open(path, "rb") as f:
            data = f.read(65536)
        return shannon_entropy(data), os.stat(path).st_size
    except OSError:
        return None, None


class SnapshotMonitor:
    """Deterministic, OS-independent monitor.

    Every `poll` seconds the folder is listed (os.scandir) and each file is identified by its
    inode (st_dev, st_ino), which survives a rename.  Comparing two snapshots gives:
        new inode                      -> created
        inode gone (2 polls in a row)  -> deleted
        same inode, new name           -> moved   (ext_changed if the suffix differs)
        same inode, new mtime / size   -> modified (content is read AFTER the change, so the
                                          entropy is always that of the final content)
    Because it never depends on when the OS delivers an event, an attacker that renames a file
    right after writing it cannot hide the write (no time-of-check/time-of-use race).
    """

    def __init__(self, folder, sink: Callable[[dict], None], poll: float = config.POLL_SEC):
        self.folder, self.sink, self.poll = str(folder), sink, poll
        self.prev: dict = {}
        self._maybe_deleted: set = set()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    # -- snapshot ----------------------------------------------------------------
    def _scan(self) -> dict:
        for _ in range(3):                         # retry if a file vanishes mid-listing
            snap, ok = {}, True
            try:
                with os.scandir(self.folder) as it:
                    for e in it:
                        if e.name.startswith(".") or e.is_dir(follow_symlinks=False):
                            continue
                        try:
                            st = e.stat(follow_symlinks=False)
                        except FileNotFoundError:
                            ok = False
                            continue
                        snap[(st.st_dev, st.st_ino)] = (e.name, st.st_mtime_ns, st.st_size)
            except FileNotFoundError:
                return {}
            if ok:
                break
        return snap

    def _emit(self, kind, path, now, ext_changed=False, entropy=None, size=0):
        self.sink(dict(t=now, kind=kind, path=path, ext_changed=ext_changed,
                       entropy=entropy, size=size or 0))

    def poll_once(self):
        now, cur = time.time(), self._scan()
        join = lambda n: os.path.join(self.folder, n)
        for key, (name, mt, size) in cur.items():
            old = self.prev.get(key)
            if old is None:
                ent, sz = _read_file(join(name))
                self._emit("created", join(name), now, entropy=ent, size=sz)
                continue
            oname, omt, osize = old
            if (mt, size) != (omt, osize) and size > 0:      # size 0 = mid-truncate, wait
                ent, sz = _read_file(join(name))
                self._emit("modified", join(oname), now, entropy=ent, size=sz)
            if name != oname:
                changed = Path(name).suffix != Path(oname).suffix
                self._emit("moved", join(oname), now, ext_changed=changed)
        nxt = dict(cur)
        for key, old in self.prev.items():
            if key not in cur:
                if key in self._maybe_deleted:               # absent twice -> really deleted
                    self._maybe_deleted.discard(key)
                    self._emit("deleted", join(old[0]), now)
                else:                                        # absent once -> might be a listing glitch
                    self._maybe_deleted.add(key)
                    nxt[key] = old
        self._maybe_deleted &= set(nxt) - set(cur)
        self.prev = nxt

    # -- thread ------------------------------------------------------------------
    def _loop(self):
        while not self._stop.is_set():
            t0 = time.time()
            try:
                self.poll_once()
            except Exception:                                # never let the monitor thread die
                pass
            self._stop.wait(max(0.0, self.poll - (time.time() - t0)))

    def start(self):
        self.prev = self._scan()                             # baseline: existing files raise no events
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2)


def FileMonitor(folder, sink, backend: str | None = None):
    """Factory: the monitor selected by config.MONITOR_BACKEND ("snapshot" or "watchdog")."""
    backend = backend or config.MONITOR_BACKEND
    return (WatchdogMonitor if backend == "watchdog" else SnapshotMonitor)(folder, sink)
