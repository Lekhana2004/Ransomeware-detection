"""Window-based feature extraction.

The SAME function (`features_from_events`) is used
  * on synthetic event streams when building the training set, and
  * on live watchdog events at run time,
so the model never sees a feature that is defined differently in production.

An event is a plain dict:
    {"t": float, "kind": "created|modified|moved|deleted", "path": str,
     "ext_changed": bool, "entropy": float | None, "size": int}
"""
from __future__ import annotations

from collections import deque
from pathlib import PurePath

import numpy as np

from config import FEATURE_NAMES, HIGH_ENTROPY, WINDOW_SEC


def shannon_entropy(data: bytes) -> float:
    """Shannon entropy H = -sum p_i log2 p_i in bits per byte (0..8)."""
    if not data:
        return 0.0
    counts = np.bincount(np.frombuffer(data, dtype=np.uint8), minlength=256)
    p = counts[counts > 0] / len(data)
    return float(-(p * np.log2(p)).sum())


def features_from_events(events, window: float = WINDOW_SEC, cpu: float = 0.0) -> np.ndarray:
    """Turn the events inside one window into the model's feature vector."""
    mods = [e for e in events if e["kind"] == "modified"]
    news = [e for e in events if e["kind"] == "created"]
    movs = [e for e in events if e["kind"] == "moved"]
    dels = [e for e in events if e["kind"] == "deleted"]

    # identity of a file = its name without extension, so "a.txt" -> "a.locked"
    # is still ONE file touched, not two.
    unique = {PurePath(e["path"]).stem for e in events}

    written = [e for e in mods + news if e.get("entropy") is not None]
    ent = [e["entropy"] for e in written]
    mean_entropy = float(np.mean(ent)) if ent else 0.0
    high_frac = float(np.mean([x > HIGH_ENTROPY for x in ent])) if ent else 0.0
    write_kb = sum(e.get("size", 0) for e in mods + news) / 1024.0

    vec = [
        len(mods) / window,
        len(movs) / window,
        len(news) / window,
        len(dels) / window,
        sum(bool(e.get("ext_changed")) for e in movs) / window,
        float(len(unique)),
        mean_entropy,
        high_frac,
        write_kb,
        float(cpu),
    ]
    assert len(vec) == len(FEATURE_NAMES)
    return np.asarray(vec, dtype=float)


class WindowFeatureExtractor:
    """Keeps the last `window` seconds of events and vectorises them on demand."""

    def __init__(self, window: float = WINDOW_SEC):
        self.window = window
        self.events: deque = deque()

    def add(self, event: dict) -> None:
        self.events.append(event)

    def compute(self, now: float, cpu: float = 0.0) -> np.ndarray:
        while self.events and self.events[0]["t"] < now - self.window:
            self.events.popleft()
        return features_from_events(list(self.events), self.window, cpu)
