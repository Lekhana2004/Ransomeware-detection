"""Load trained detectors and score a live feature vector."""
from __future__ import annotations

import joblib
import numpy as np

from config import MODELS_DIR
from models.gd_logistic import GDLogisticRegression


class DetectorBank:
    def __init__(self):
        self.gd = GDLogisticRegression.load(MODELS_DIR / "gd_logistic.json")
        self.rf = joblib.load(MODELS_DIR / "random_forest.joblib")
        self.iso = joblib.load(MODELS_DIR / "isolation_forest.joblib")
        self.base = joblib.load(MODELS_DIR / "baseline.joblib")

    def score(self, x: np.ndarray) -> dict:
        x = np.atleast_2d(x)
        return {
            "gd_prob": float(self.gd.predict_proba(x)[0]),
            "rf_prob": float(self.rf.predict_proba(x)[0, 1]),
            "iso_flag": bool(self.iso.predict(x)[0] == -1),
            "baseline_flag": bool(self.base.predict(x)[0]),
        }
