"""Train and evaluate four detectors on synthetic behavioural windows.

  1. mu + 3 sigma threshold      (statistical baseline - no learning)
  2. Isolation Forest            (unsupervised anomaly detection, trained on benign only)
  3. Random Forest               (supervised, tree ensemble)
  4. Gradient-descent logistic regression (supervised, OUR optimisation core)

Run:  python -m models.train_model
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import joblib
import numpy as np
from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score,
                             precision_score, recall_score, roc_auc_score)

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from config import BASELINE_FEATURE, DATA_DIR, FEATURE_NAMES, MODELS_DIR, SEED, SIGMA_K  # noqa: E402
from models.baseline import ThresholdBaseline  # noqa: E402
from models.gd_logistic import GDLogisticRegression  # noqa: E402
from simulation.data_generator import BENIGN, RANSOM, generate_dataset, save_csv  # noqa: E402


def build_models(Xtr, ytr):
    base = ThresholdBaseline(FEATURE_NAMES.index(BASELINE_FEATURE), SIGMA_K).fit(Xtr[ytr == 0])
    iso = IsolationForest(n_estimators=200, contamination=0.05, random_state=SEED).fit(Xtr[ytr == 0])
    rf = RandomForestClassifier(n_estimators=200, random_state=SEED, n_jobs=-1).fit(Xtr, ytr)
    gd = GDLogisticRegression(lr=0.5, n_iter=3000, l2=1e-3, expand=True).fit(Xtr, ytr)
    return base, iso, rf, gd


def predictors(base, iso, rf, gd):
    """name -> (hard_prediction_fn, continuous_score_fn)"""
    return {
        "mu+3sigma baseline": (base.predict, base.score),
        "Isolation Forest": (lambda X: (iso.predict(X) == -1).astype(int),
                             lambda X: -iso.score_samples(X)),
        "Random Forest": (rf.predict, lambda X: rf.predict_proba(X)[:, 1]),
        "GD logistic regression": (gd.predict, gd.predict_proba),
    }


def evaluate(preds, Xte, yte, sc_te):
    out = {}
    for name, (hard, soft) in preds.items():
        yp = hard(Xte)
        tn, fp, fn, tp = confusion_matrix(yte, yp, labels=[0, 1]).ravel()
        out[name] = {
            "accuracy": accuracy_score(yte, yp),
            "precision": precision_score(yte, yp, zero_division=0),
            "recall": recall_score(yte, yp),
            "f1": f1_score(yte, yp),
            "roc_auc": roc_auc_score(yte, soft(Xte)),
            "false_positive_rate": fp / (fp + tn),
            "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
            "flag_rate_by_scenario": {s: float(yp[sc_te == s].mean()) for s in BENIGN + RANSOM},
        }
    return out


def main(n_train=6000, n_test=3000):
    Xtr, ytr, sctr = generate_dataset(n_train, seed=SEED)
    Xte, yte, scte = generate_dataset(n_test, seed=SEED + 1)       # independent test set
    DATA_DIR.joinpath("processed").mkdir(parents=True, exist_ok=True)
    save_csv(DATA_DIR / "processed" / "train.csv", Xtr, ytr, sctr)
    save_csv(DATA_DIR / "processed" / "test.csv", Xte, yte, scte)

    base, iso, rf, gd = build_models(Xtr, ytr)
    MODELS_DIR.mkdir(exist_ok=True)
    joblib.dump(rf, MODELS_DIR / "random_forest.joblib")
    joblib.dump(iso, MODELS_DIR / "isolation_forest.joblib")
    joblib.dump(base, MODELS_DIR / "baseline.joblib")
    gd.save(MODELS_DIR / "gd_logistic.json")

    preds = predictors(base, iso, rf, gd)
    gd_raw = GDLogisticRegression(lr=0.5, n_iter=3000, l2=1e-3, expand=False).fit(Xtr, ytr)
    preds = {**preds, "GD logistic (raw 10 features)": (gd_raw.predict, gd_raw.predict_proba)}
    results = evaluate(preds, Xte, yte, scte)
    results["_meta"] = {"n_train": n_train, "n_test": n_test,
                        "baseline_mu": base.mu, "baseline_sigma": base.sigma,
                        "baseline_threshold": base.threshold,
                        "gd_iterations": len(gd.loss_history),
                        "gd_final_loss": gd.loss_history[-1]}
    (DATA_DIR / "processed" / "results.json").write_text(json.dumps(results, indent=2))

    print(f"{'detector':26s} acc    prec   recall f1     auc    FPR")
    for k, r in results.items():
        if k.startswith("_"):
            continue
        print(f"{k:26s} {r['accuracy']:.3f}  {r['precision']:.3f}  {r['recall']:.3f}  "
              f"{r['f1']:.3f}  {r['roc_auc']:.3f}  {r['false_positive_rate']:.3f}")
    print("baseline mu=%.2f sigma=%.2f threshold=%.2f files/s" %
          (base.mu, base.sigma, base.threshold))
    print("GD: %d iterations, final loss %.4f" % (len(gd.loss_history), gd.loss_history[-1]))
    return results


if __name__ == "__main__":
    main()
