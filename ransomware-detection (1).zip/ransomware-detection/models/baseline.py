"""Statistical baseline: flag a window when feature > mu + k*sigma (mu, sigma from benign data)."""
import numpy as np


class ThresholdBaseline:
    def __init__(self, feature_index: int, k: float = 3.0):
        self.i, self.k = feature_index, k
        self.mu = self.sigma = self.threshold = None

    def fit(self, X_benign):
        v = np.asarray(X_benign)[:, self.i]
        self.mu, self.sigma = float(v.mean()), float(v.std())
        self.threshold = self.mu + self.k * self.sigma
        return self

    def score(self, X):
        return np.atleast_2d(X)[:, self.i]

    def predict(self, X):
        return (self.score(X) > self.threshold).astype(int)
