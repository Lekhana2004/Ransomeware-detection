"""Logistic regression trained with GRADIENT DESCENT, written from scratch (NumPy).

This is the optimisation core of the project.

Model          p(y=1|x) = sigma(w.x + b),   sigma(z) = 1 / (1 + e^-z)
Loss (to MIN)  J(w,b)   = -(1/n) sum[ y log p + (1-y) log(1-p) ] + (lambda/2)||w||^2
Gradient       dJ/dw    = (1/n) X^T (p - y) + lambda w          dJ/db = (1/n) sum(p - y)
Descent step   theta <- theta - eta * grad J(theta)

Gradient ASCENT on the penalised log-likelihood  L = -J  gives the identical
update (theta <- theta + eta * grad L); `ascent=True` implements it that way.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np


def expand_features(X):
    """Non-linear feature map so a LINEAR model can express behavioural AND-rules.

    columns of X follow config.FEATURE_NAMES:
      0 mod 1 rename 2 create 3 delete 4 ext_change 5 unique | 6 entropy 7 high_frac 8 write_kb 9 cpu
    adds: log(1+count) for the six count features, and interaction terms
    'high-entropy x renaming', 'high-entropy x extension change', ...
    """
    X = np.atleast_2d(np.asarray(X, float))
    logc = np.log1p(X[:, :6])
    hi, ent = X[:, 7:8], X[:, 6:7] / 8.0
    inter = np.hstack([hi * X[:, 1:2], hi * X[:, 4:5], ent * X[:, 4:5],
                       hi * logc[:, 5:6], hi * logc[:, 0:1]])
    return np.hstack([X, logc, inter])


def sigmoid(z):
    z = np.clip(z, -35, 35)           # avoid overflow in exp
    return 1.0 / (1.0 + np.exp(-z))


class GDLogisticRegression:
    def __init__(self, lr=0.1, n_iter=1500, l2=1e-3, batch_size=None,
                 momentum=0.0, tol=1e-9, ascent=False, seed=0, expand=False):
        self.lr, self.n_iter, self.l2 = lr, n_iter, l2
        self.batch_size, self.momentum, self.tol = batch_size, momentum, tol
        self.ascent, self.seed, self.expand = ascent, seed, expand
        self.w = self.b = self.mu_ = self.sigma_ = None
        self.loss_history: list[float] = []
        self.gradnorm_history: list[float] = []
        self.w_history: list[np.ndarray] = []

    # -- maths ---------------------------------------------------------------
    def _z(self, X):
        return X @ self.w + self.b

    def loss(self, X, y):
        p = np.clip(sigmoid(self._z(X)), 1e-12, 1 - 1e-12)
        nll = -np.mean(y * np.log(p) + (1 - y) * np.log(1 - p))
        return float(nll + 0.5 * self.l2 * np.sum(self.w ** 2))

    def gradient(self, X, y):
        """Analytic gradient of the loss J with respect to (w, b)."""
        err = sigmoid(self._z(X)) - y
        gw = X.T @ err / len(y) + self.l2 * self.w
        gb = err.mean()
        return gw, float(gb)

    # -- training ------------------------------------------------------------
    def fit(self, X, y, keep_w_history=False):
        X = np.asarray(X, float)
        X = expand_features(X) if self.expand else X
        y = np.asarray(y, float)
        self.mu_ = X.mean(axis=0)
        self.sigma_ = X.std(axis=0)
        self.sigma_[self.sigma_ == 0] = 1.0
        Xs = (X - self.mu_) / self.sigma_

        rng = np.random.default_rng(self.seed)
        n, d = Xs.shape
        self.w, self.b = np.zeros(d), 0.0
        vw, vb = np.zeros(d), 0.0
        self.loss_history, self.gradnorm_history, self.w_history = [], [], []
        prev = np.inf

        for _ in range(self.n_iter):
            if self.batch_size:                       # mini-batch (stochastic) GD
                idx = rng.choice(n, size=min(self.batch_size, n), replace=False)
                Xb, yb = Xs[idx], y[idx]
            else:                                     # full-batch GD
                Xb, yb = Xs, y
            gw, gb = self.gradient(Xb, yb)            # gradient of the LOSS J

            if self.ascent:                           # ascent on L = -J  (same step)
                gw_L, gb_L = -gw, -gb
                vw = self.momentum * vw + gw_L
                vb = self.momentum * vb + gb_L
                self.w = self.w + self.lr * vw
                self.b = self.b + self.lr * vb
            else:                                     # descent on J
                vw = self.momentum * vw + gw
                vb = self.momentum * vb + gb
                self.w = self.w - self.lr * vw
                self.b = self.b - self.lr * vb

            cur = self.loss(Xs, y)
            self.loss_history.append(cur)
            self.gradnorm_history.append(float(np.linalg.norm(np.append(gw, gb))))
            if keep_w_history:
                self.w_history.append(self.w.copy())
            if not self.batch_size and abs(prev - cur) < self.tol:
                break
            prev = cur
        return self

    # -- inference -------------------------------------------------------------
    def _scale(self, X):
        X = np.atleast_2d(np.asarray(X, float))
        X = expand_features(X) if self.expand else X
        return (X - self.mu_) / self.sigma_

    def predict_proba(self, X):
        return sigmoid(self._scale(X) @ self.w + self.b)

    def predict(self, X, threshold=0.5):
        return (self.predict_proba(X) >= threshold).astype(int)

    # -- persistence -----------------------------------------------------------
    def save(self, path):
        Path(path).write_text(json.dumps({
            "w": self.w.tolist(), "b": self.b,
            "mu": self.mu_.tolist(), "sigma": self.sigma_.tolist(),
            "lr": self.lr, "l2": self.l2, "expand": self.expand,
            "loss_history": self.loss_history,
        }))

    @classmethod
    def load(cls, path):
        d = json.loads(Path(path).read_text())
        m = cls(lr=d["lr"], l2=d["l2"], expand=d.get("expand", False))
        m.w, m.b = np.array(d["w"]), d["b"]
        m.mu_, m.sigma_ = np.array(d["mu"]), np.array(d["sigma"])
        m.loss_history = d.get("loss_history", [])
        return m
